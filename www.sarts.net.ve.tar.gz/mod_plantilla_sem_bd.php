<?php
include ("security_system.php");
ini_set('error_reporting',0);
?>
<HTML>
<HEAD>
<TITLE>Resultado Incluir Jornada. Sistema ARTS Online</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}


</script>

<script language="javascript">
  function refreshImg(){
     document.carga_traba.picture.src = 'file:///'+ document.carga_traba.imageField.value;
   }
</script>

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1251">
<link rel="stylesheet" href="main.css" type="text/css" http-equiv="Window-target" content="_top"/>
<style type="text/css">
<!--
.Estilo30 {
	font-size: 14;
	color: #0000FF;
}
.Estilo34 {text-decoration: none; font-size: 12px; text-transform: uppercase;}
.Estilo36 {
	font-size: 16px;
	color: #FF0000;
	font-weight: bold;
}
.Estilo37 {font-size: 16px}
a:link {
	color: #000000;
}
a:visited {
	color: #666666;
}
.Estilo44 {
	font-size: 18;
	color: #FFFFFF;
}
.Estilo47 {text-transform: uppercase; color: 069300; text-decoration: none; font-size: 12px;}
.Estilo48 {color: #FFFFFF}
a:active {
	color: #FFFFFF;
}
a:hover {
	color: #FFFFFF;
}
-->
</style>
<script type="text/JavaScript">
<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}
//-->
</script>
<script type="text/javascript" language="JavaScript1.2" src="stmenu.js"></script>
</HEAD>
<BODY BGCOLOR=#FFFFFF background="images/bgb.gif" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 onLoad="MM_preloadImages('images/18-1.gif','images/8-1.gif')" tracingsrc="images/-downdis.gif" tracingopacity="100" oncontextmenu="return false">
<td colspan="2" valign="middle"><div align="center"> 
       <table width="777" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="1">
    <td width="776" align="right" background="images/index_01.gif"><img src="images/index_03.gif" width=59 height=34 alt=""><a href="inicio.html"><img src="images/index_ini.gif" alt="" width=82 height=34 border="0"></a><img src="images/index_faq.GIF" width=82 height=34 alt=""><img src="images/index_link.gif" width=89 height=34 alt=""><a href="finalizar_sesion.php"><img src="images/index_sarts.gif" alt="" width=71 height=34 border="0"></a><img src="images/index_contac.GIF" width=85 height=34 alt=""></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td> <div align="right"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"></font>
	  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="778" height="174">
        <param name="movie" value="3.swf">
        <param name="quality" value="high">
        <embed src="3.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="778" height="174"></embed>
	    </object>
	</div></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="450" background="images/index_23.gif"><img src="images/index_22.gif" width=174 height=35 alt=""></td>
	<td background="images/index_27.gif"><img src="images/index_25.jpg" width=96 height=35 alt=""><img src="images/index_soft.GIF" width=92 height=35 alt=""></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" bgcolor="#FAFAFA">
  <tr>
	<td width="481" align="right" bgcolor="#FFFFFF"> 
	  <table width="535" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
		<tr>
		  
		</tr>
	  </table>
	  <table width="535" border="0" cellspacing="0" cellpadding="0">
		<tr> 
		  <td width="5">&nbsp;</td>
		  <td width="23" align="center" bgcolor="#FFFFFF">&nbsp; </td>
		  <td width="507" valign="top" class="bg_product"> 
			<table width="526" border="0" cellspacing="0" cellpadding="0">
                  <tr> 
				<td width="508" bgcolor="#FFFFFF" class="t12b"><table width="101%" border="0" cellspacing="0" cellpadding="0">
                        <tr> 
                          <td height="471" align="center" bgcolor="#FFFFFF">
                            <p>
<?php
include ("includes/bdkey.php");

$nombre_plantilla=$_POST['nombre_plantilla'];

$querymain = mysql_query("select * from plantillas where nombre_plantilla='$nombre_plantilla'");
if(mysql_num_rows($querymain)!=0)
	{
	$cuentam=$_COOKIE['usuario'];
	
	$plt = "INSERT INTO plant (cuenta,nombre_plantilla) VALUES('$cuentam','$nombre_plantilla')";
	$resultplt = mysql_query($plt);
	
	$hd[0]=$_POST[hd0];
	$hd[1]=$_POST[hd1];
	$hd[2]=$_POST[hd2];
	$hd[3]=$_POST[hd3];
	$hd[4]=$_POST[hd4];
	$hd[5]=$_POST[hd5];
	$hd[6]=$_POST[hd6];
	
	$hed[0]=$_POST[hed0];
	$hed[1]=$_POST[hed1];
	$hed[2]=$_POST[hed2];
	$hed[3]=$_POST[hed3];
	$hed[4]=$_POST[hed4];
	$hed[5]=$_POST[hed5];
	$hed[6]=$_POST[hed6];
	
	$hedp[0]=$_POST[hedp0];
	$hedp[1]=$_POST[hedp1];
	$hedp[2]=$_POST[hedp2];
	$hedp[3]=$_POST[hedp3];
	$hedp[4]=$_POST[hedp4];
	$hedp[5]=$_POST[hedp5];
	$hedp[6]=$_POST[hedp6];
	
	$trcd[0]=$_POST[trcd0];
	$trcd[1]=$_POST[trcd1];
	$trcd[2]=$_POST[trcd2];
	$trcd[3]=$_POST[trcd3];
	$trcd[4]=$_POST[trcd4];
	$trcd[5]=$_POST[trcd5];
	$trcd[6]=$_POST[trcd6];
	
	$bonocturno[0]=$_POST[bonocturno0];
	$bonocturno[1]=$_POST[bonocturno1];
	$bonocturno[2]=$_POST[bonocturno2];
	$bonocturno[3]=$_POST[bonocturno3];
	$bonocturno[4]=$_POST[bonocturno4];
	$bonocturno[5]=$_POST[bonocturno5];
	$bonocturno[6]=$_POST[bonocturno6];
	
	$hen[0]=$_POST[hen0];
	$hen[1]=$_POST[hen1];
	$hen[2]=$_POST[hen2];
	$hen[3]=$_POST[hen3];
	$hen[4]=$_POST[hen4];
	$hen[5]=$_POST[hen5];
	$hen[6]=$_POST[hen6];
	
	$henp[0]=$_POST[henp0];
	$henp[1]=$_POST[henp1];
	$henp[2]=$_POST[henp2];
	$henp[3]=$_POST[henp3];
	$henp[4]=$_POST[henp4];
	$henp[5]=$_POST[henp5];
	$henp[6]=$_POST[henp6];
	
	$trcn[0]=$_POST[trcn0];
	$trcn[1]=$_POST[trcn1];
	$trcn[2]=$_POST[trcn2];
	$trcn[3]=$_POST[trcn3];
	$trcn[4]=$_POST[trcn4];
	$trcn[5]=$_POST[trcn5];
	$trcn[6]=$_POST[trcn6];
	
	$clave221[0]=$_POST[clave2210];
	$clave221[1]=$_POST[clave2211];
	$clave221[2]=$_POST[clave2212];
	$clave221[3]=$_POST[clave2213];
	$clave221[4]=$_POST[clave2214];
	$clave221[5]=$_POST[clave2215];
	$clave221[6]=$_POST[clave2216];
	
	$clave277[0]=$_POST[clave2770];
	$clave277[1]=$_POST[clave2771];
	$clave277[2]=$_POST[clave2772];
	$clave277[3]=$_POST[clave2773];
	$clave277[4]=$_POST[clave2774];
	$clave277[5]=$_POST[clave2775];
	$clave277[6]=$_POST[clave2776];
	
	$cont=0;
	while ($cont<=6)
		{
		@$hdm=$hd[$cont];
		$hedm=$hed[$cont];
		$hedpm=$hedp[$cont];
		$trcdm=$trcd[$cont];
		$bonocturnom=$bonocturno[$cont];
		$henm=$hen[$cont];
		$henpm=$henp[$cont];
		$trcnm=$trcn[$cont];
		$clave221m=$clave221[$cont];
		$clave277m=$clave277[$cont];
		$diam=$cont;
	
		$sql = "Update jornada Set hd='$hdm',hed='$hedm',hedp='$hedpm',trcd='$trcdm',bonocturno='$bonocturnom',hen='$henm',henp='$henpm',trcn='$trcnm',clave221='$clave221m',clave277='$clave277m' where cuenta='$cuentam' and nombre_plantilla='$nombre_plantilla' and dia='$diam'";
		$result = mysql_query($sql);
		$cont=$cont+1;
		}
	echo "<H2><font color='blue'>Los datos fueron guardados con &eacute;xito!!!</font></H2>";
	echo '<div align="center">';		
	}else{
		echo "<H2><font color='red'>Error!!!</font></H2>";
		echo "<H2><font color='red'>Plantilla eliminada por otro usuario, consulte al</font></H2>";
		echo "<H2><font color='red'>Administrador del Sistema</font></H2>";
	}
?>
                            </p>
                            <p>&nbsp;</p>
							<div align="center"> <span class="t12g Estilo30"><span class="Estilo34">&iquest;Desea modificar otra plantilla?
                              </p>
                                </span></span>
                              <table width="243" border="0">
                                  <tr>
                                    <td width="113"><div align="center"><font color="#FF0000" size="2"><a title="Ayuda sobre el manejo del SARTS" href="#">
                                      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="103" height="24">
                                        <param name="movie" value="button43.swf">
                                        <param name="quality" value="high">
                                        <embed src="button43.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="103" height="24" ></embed>
                                      </object>
                                    </a></font></div></td>
                                    <td width="114"><div align="center">
                                      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="103" height="24">
                                        <param name="BGCOLOR" value="">
                                        <param name="movie" value="button19.swf">
                                        <param name="quality" value="high">
                                        <embed src="button19.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="103" height="24" ></embed>
                                      </object>
                                    </div></td>
                                  </tr>
                              </table>
</div>
                            <h1 align="right">

                              <table width="47%" border="0" cellspacing="0" cellpadding="0">
                                <tr> </tr>
                              </table>
                          </h1></td>
					</tr>
				  </table>				</td>
				<td width="16">&nbsp;</td>
			  </tr>
			</table>		  </td>
		</tr>
	  </table>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <table width="5" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="5">&nbsp;</td>
        </tr>
      </table>
      </td>
	    <td width="297" valign="top" background="images/index_32.gif">
		   <div align="center" class="t14w Estilo37"></div>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
		      <td height="8"><span class="t12g Estilo44"><span class="Estilo47"><img src="images/index_57.gif" width=240 height=1 alt="">
		        </span></span>
		        <div align="center" class="t12g Estilo44">SISTEMA ARTS</div>

<ul class="Estilo9"><li class="Estilo11 Estilo48"><a title="inicio.htm" href="inicio.html" target="_self">Inicio</a></li>
	<li class="Estilo11 Estilo48"><a title="antecedentes.htm" href="antecedentes.htm" target="_self">Antecedentes</a></li>
	<li class="Estilo11 Estilo48"><a title="Objetivos.html" href="Objetivos.html" target="_self">Objetivos</a></li>
	<strong></br>
	</strong>
	<li class="Estilo11 Estilo48"><span class="Estilo48 Estilo10"><strong>Trabajadores</strong></span>
	<ul>
		<li><a title="Cargar Traba" href="cargar_traba.php" target="_self">Inclusi&oacute;n</a></li>
		<li><a title="Consultar Trabajador" href="consulta_trabaj.php" target="_self">Consulta - Reporte</a></li>
		<li><a title="Actualizar Trabajador" href="actualizar_trabaj.php" target="_self">Modificaci&oacute;n</a></li>
		<li><a title="Eliminar Trabajador nivel Usuario" href="elim_traba.php" target="_self">Eliminaci&oacute;n</a></li>
		<li><a title="Men� Gr�fica datos trabajador " href="menu_graficar_trabaj.php" target="_self">Graficaci&oacute;n</a></li>
    	</ul></ul>
		
		<ul class="Estilo9"><li class="Estilo11 Estilo48"><span class="Estilo10"><strong>Jornadas</strong></span>
		<ul>
		<li><a title="Cargar Jornadas" href="cargar_jornada.php" target="_self">Inclusi&oacute;n</a></li>
		<li><a title="Consultar Jornadas" href="consulta_jornada.php" target="_self">Consulta</a></li>
		<li><a title="Modiciar Jornadas" href="actualizar_jornada.php" target="_self">Modificaci&oacute;n</a></li>
		<li><a title="Eliminar Jornadas" href="elim_jornada.php" target="_self">Eliminaci&oacute;n</a></li>
		<li><span class="Estilo48"><a title="menu_graficar_jornada.php" href="menu_graficar_jornada.php" target="_self">Graficaci&oacute;n</a></span></li>
		</ul></ul>
		<ul class="Estilo9"><li class="Estilo48 Estilo11"><strong>Plantillas</strong></li>
		<ul>
		<li><a title="Crear Plantilla" href="crear_plantilla.php" target="_self">Inclusi&oacute;n</a></li>
		<li><a title="Consultar Plantilla" href="consulta_plantilla.php" target="_self">Consultar</a></li>
		<li><a title="Modificar Plantilla" href="actualizar_plantilla.php" target="_self">Modificaci&oacute;n</a></li>
		<li><a title="Eliminar Plantilla" href="elim_plantilla.php" target="_self">Eliminaci&oacute;n</a></li>
		</ul></ul>
		<ul class="Estilo9"><li class="Estilo48"><span class="Estilo48 Estilo10"><strong>Menu Admi</strong></span><span class="Estilo10"><strong>n</strong></span>
		<ul>
		<li><strong>Trabajadores</strong>
			<ul>
			<li><a title="consulta_trabaj.php" href="consulta_trabaj.php" target="_self">Consulta - Reporte</a></li>
			<li><a title="actualizar_trabaj.php" href="actualizar_trabaj.php" target="_self">Modificaci&oacute;n</a></li>
        	<li><a title="elim_traba.php" href="elim_traba.php" target="_self">Eliminacion</a></li>
        	<li><a title="menu_graficar_trabaj.php" href="menu_graficar_trabaj.php" target="_self">Graficaci&oacute;n</a></li>
        </ul></li>
	<li><strong>Usuarios</strong>
        <ul>
        <li><a title="Crear Usuario" href="cargar_user.php" target="_self">Inclusi&oacute;n</a></li>
		<li><a title="Pr�ximanmente" href="consulta_user.php" target="_self">Consulta - Reporte</a></li>
		<li><a title="Pr�ximanmente" href="actualizar_user.php" target="_self">Modificaci&oacute;n</a></li>
		<li><a title="Pr�ximanmente" href="elim_user.php" target="_self">Eliminaci&oacute;n</a></li>
		<li><a title="Pr�ximanmente" href="menu_graficar_user.php" target="_self">Graficaci&oacute;n</a></li>
		</ul></li>
		</ul>
	<li class="Estilo48"><strong>Adicionales</strong>
		<ul><li class="Estilo11 Estilo48"><a title="Descargas" href="download.php" target="_self">Descargas</a></li>
		<li class="Estilo11 Estilo48"><a title="Men� SARTS" href="menu_sarts.html">Sistema ARTS</a></li>
		<li class="Estilo11 Estilo48"><a title="Contactar al Administrador" href="#">Contacto SARTS</a></li>
		<li class="Estilo11 Estilo48"><a title="FAQ" href="#">Preguntas del Sistema</a>
		<li class="Estilo11 Estilo48"><a title="Manual de Usuario" href="#">Manual de Usuario</a></li>
		</ul></li>
	<li class="Estilo11 Estilo48">Ayuda Online (proximamente)</li>
		<li class="Estilo11 Estilo48">Chat SARTS(pr&oacute;ximanete)</li>
        </ul>	          </td>
		</tr>
	  </table>
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
		  <td><img src="images/index_57.gif" width=240 height=1 alt=""></td>
		</tr>
	  </table>
      <div align="left">
        <div align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Desarrollado 
          para:</strong></font></strong></font></strong></font>        </div>
        <div align="center"><img src="images/logo de cadafe_2.gif" width="148" height="90"></div>
            <p align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#CCCCCC" size="4">Regi&oacute;n 
              4</font></strong></font></strong></font></strong></font></p>
            <p align="center">
          <script><!--
dows = new Array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado");
months = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
now = new Date();
dow = now.getDay();
d = now.getDate();
m = now.getMonth();
h = now.getTime();
y = now.getFullYear();
document.write(dows[dow]+" "+d+" de "+months[m]+" de "+y);
//--></script></p></div></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td background="images/index_66.gif" class="t12w"><b>&nbsp;&nbsp;&copy;2006-2007 
      MaxSystem.NET &nbsp;Derechos Reservados</b></td>
	<td width="102"><img src="images/index_69.jpg" width=102 height=36 alt=""></td>
	<td width="222" background="images/index_70.gif" align="center" class="t12w"><div align="center"><a href="#" class="t12w"><b>Data/Privacidad</b></a><b> 
        � <a href="#" class="t12w">Accesabilidad</a></b></div></td>
  </tr>
</table>
</div></td>

</BODY>
</HTML>