<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
 "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>AJAX Contact Form</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<script type="text/javascript" src="js/prototype.js"></script>
	<script type="text/javascript" src="js/scriptaculous.js"></script>
	<script type="text/javascript" src="js/wforms.js"></script>
	<script type="text/javascript" src="js/localization-es.js"></script>
	<script type="text/javascript" src="js/contact.js"></script>
	<script type="text/javascript" src="/mint/mint.js.php"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css" media="screen, projection" />
	<!--

	Hola!
	
	Estas viendo el codigo de una parte de alex | weblog.
	Puedes curiosear lo que quieras, si encuentras algo que
	te gusta, ponte en contacto conmigo antes de tomarlo
	prestado.
	
	Normalmente no tengo inconveniente en compartir codigo
	con quien pregunta, pero las imagenes ya son otra cosa.
	Aunque si no preguntas, nunca sabras que habria	pasado.
	
	Si encuentro este codigo y/o mis imagenes en tu sitio
	*sin* mi consentimiento, probablemente no sere muy
	generoso.
	
	Ahora ya estas avisado.

	-->

</head>
<body>
<div id="wrap">
    <div id="contact">
	<h1> Contacto</h1>
	<div id="comments">
	<p id="loadBar" style="display:none;">
		<strong>Enviando correo. Por favor espere&#8230;</strong>
		<img src="img/loading.gif" alt="Loading..." title="Enviando Correo" />
	</p>
	<?php if ( (!$success) && (!$error) ) { ?>
	<ul id="status">
		<li><span class="req">*</span>Por Favor, rellene todos los campos obligatorios.</li>
	</ul>
	<?php } if ($success) { ?>
	<ul id="status">
		<li class="scsMsg">OK! Su correo se ha procesado correctamente. Gracias por su interes.</li>
	</ul>
	<?php } if ($error) { ?>
	<ul id="status">
		<li>Error! Ha ocurrido algun error al enviar su correo.</li>
		<li>Por Favor revise los datos del formulario y vuelva a intentarlo.</li>
		<?php if ($fail[0]) { ?><li class="bigerr"><?php print $fail[0]; ?></li><?php } ?>
	</ul>
	<?php } ?>
      </div>
	<form action="scripts/contact.php" <?php if ($success) { ?>style="display:none;" <?php } ?>method="post" id="cForm">
		<fieldset><legend>Datos Personales &raquo;</legend>
		<div><label for="name"><span class="req">*</span>Nombre</label>
		<input type="text" name="name" id="name" value="<?php echo $name; ?>" class="required<?php if ($fail[1]) { ?> errFld<?php } ?>" />
		<?php if ($fail[1]) { ?><span class="errMsg"><?php print $fail[1]; ?></span><?php } ?><br /></div>
		<div><label for="email"><span class="req">*</span>Email</label>
		<input type="text" name="email" id="email" value="<?php echo $email; ?>" class="validate-email required<?php if ($merr) { ?> errFld<?php } ?>" />
		<?php if ($merr) { 
			foreach ($merr as $key => $value) {
		    	    print '<span class="errMsg">'.$value.'</span>';
			}
		} ?><br /></div>
		<div><input type="checkbox" name="selfcopy" id="selfcopy" value="send" /><label for="selfcopy">Enviar copia</label><br /></div>
		</fieldset>
		<fieldset><legend>Envianos tu Mensaje &raquo;</legend>
		<div><label for="sub"><span class="req">*</span>Motivo del Mensaje</label>
		<input type="text" name="sub" id="sub" value="<?php echo $sub; ?>" class="required<?php if ($fail[2]) { ?> errFld<?php } ?>" />
		<?php if ($fail[2]) { ?><span class="errMsg"><?php print $fail[2]; ?></span><?php } ?><br /></div>
		<div><label for="note"><span class="req">*</span>Mensaje</label>
		<textarea cols="50" rows="5" name="note" id="note" onkeyup="val=this.value; if (val.length > 800) { alert('Lo siento, has sobrepasado el limite de 800 caracteres'); this.value = val.substring(0,800); } this.form.counter.value=800-parseInt(this.value.length);" class="required<?php if ($fail[3] || $fail[4]) { ?> errFld<?php } ?>"><?php echo $note; ?></textarea>
		<?php if ($fail[3] || $fail[4]) { ?><span class="errMsg"><?php print $fail[3]; print $fail[4]; ?></span><?php } ?><br /></div>
		<div><input class="submit" name="submit" type="submit" id="sendEmail" value=" Enviar Correo " />
		<label for="counter" style="display:none;">Caracteres Disponibles</label>
		<input type="text" name="counter" id="counter" value="800" size="2" readonly="readonly" />
		<input type="hidden" name="posted" id="posted" value="true" /><br /></div>
		<?php $text_len = preg_match_all('/./', $str, $dummy); ?>
		</fieldset>
	</form>
	</div>
    <p>&nbsp;</p>
</div>
</body>
</html>
<?php
session_unset();
session_destroy();
?>