<?php
include ("security_system.php");
ini_set('error_reporting',0);
?>
<HTML>
<HEAD>
<TITLE>Resultado Incluir Jornada. Sistema ARTS Online</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}


</script>

<script language="javascript">
  function refreshImg(){
     document.carga_traba.picture.src = 'file:///'+ document.carga_traba.imageField.value;
   }
</script>

<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1251">
<link rel="stylesheet" href="main.css" type="text/css" http-equiv="Window-target" content="_top"/>
<style type="text/css">
<!--
.Estilo30 {
	font-size: 14;
	color: #0000FF;
}
.Estilo34 {text-decoration: none; font-size: 12px; text-transform: uppercase;}
.Estilo36 {
	font-size: 16px;
	color: #FF0000;
	font-weight: bold;
}
.Estilo37 {font-size: 16px}
a:link {
	color: #000000;
}
a:visited {
	color: #666666;
}
.Estilo44 {
	font-size: 18;
	color: #FFFFFF;
}
.Estilo47 {text-transform: uppercase; color: 069300; text-decoration: none; font-size: 12px;}
.Estilo48 {color: #FFFFFF}
a:active {
	color: #FFFFFF;
}
a:hover {
	color: #FFFFFF;
}
.Estilo49 {color: #0000FF}
.Estilo50 {font-size: 14}
-->
</style>
<script type="text/JavaScript">
<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}
//-->
</script>
<script type="text/javascript" language="JavaScript1.2" src="stmenu.js"></script>
</HEAD>
<BODY BGCOLOR=#FFFFFF background="images/bgb.gif" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 onLoad="MM_preloadImages('images/18-1.gif','images/8-1.gif')" tracingsrc="images/-downdis.gif" tracingopacity="100" oncontextmenu="return false">
<td colspan="2" valign="middle"><div align="center"> 
       <table width="777" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="1">
    <td width="776" align="right" background="images/index_01.gif"><img src="images/index_03.gif" width=59 height=34 alt=""><a href="inicio.html"><img src="images/index_ini.gif" alt="" width=82 height=34 border="0"></a><img src="images/index_faq.GIF" width=82 height=34 alt=""><img src="images/index_link.gif" width=89 height=34 alt=""><a href="finalizar_sesion.php"><img src="images/index_sarts.gif" alt="" width=71 height=34 border="0"></a><img src="images/index_contac.GIF" width=85 height=34 alt=""></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td> <div align="right"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"></font>
	  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="778" height="174">
        <param name="movie" value="3.swf">
        <param name="quality" value="high">
        <embed src="3.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="778" height="174"></embed>
	    </object>
	</div></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="450" background="images/index_23.gif"><img src="images/index_22.gif" width=174 height=35 alt=""></td>
	<td background="images/index_27.gif"><img src="images/index_25.jpg" width=96 height=35 alt=""><img src="images/index_soft.GIF" width=92 height=35 alt=""></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" bgcolor="#FAFAFA">
  <tr>
	<td width="481" align="right" bgcolor="#FFFFFF"> 
	  <table width="535" border="0" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#FFFFFF">
		<tr>
		  
		</tr>
	  </table>
	  <table width="535" border="0" cellspacing="0" cellpadding="0">
		<tr> 
		  <td width="5">&nbsp;</td>
		  <td width="23" align="center" bgcolor="#FFFFFF">&nbsp; </td>
		  <td width="507" valign="top" class="bg_product"> 
			<table width="526" border="0" cellspacing="0" cellpadding="0">
                  <tr> 
				<td width="508" bgcolor="#FFFFFF" class="t12b"><table width="101%" border="0" cellspacing="0" cellpadding="0">
                        <tr> 
                          <td height="471" align="center" bgcolor="#FFFFFF">
                            <p>
<?php
include ("includes/bdkey.php");

if($_POST['ci']==0){
?>
	<span class="Estilo36"><u>Atenci&oacute;n</u></span></p>
	<p><span class="Estilo36">No se insert� ning&uacute;n dato</span></p>
	<p><span class="Estilo36">porque no se seleccion&oacute; trabajador </span></p>
	<p><span class="Estilo36">alguno para la fecha <?php echo $fecha; ?></span>

<?php
}else{

$horariom=$_POST['horario'];

$qry=mysql_query("SELECT * FROM aditamentos");
while ($row=mysql_fetch_array($qry)){
	$manejobd=$row['manejo'];
	$largo_si=$row['largo_si'];
	$largo_ci=$row['largo_ci'];
	$corto_si=$row['corto_si'];
	$corto_ci=$row['corto_ci'];
}
$arrayfecha[0]=$_POST['fechadia1'];
$arrayfecha[1]=$_POST['fechadia2'];
$arrayfecha[2]=$_POST['fechadia3'];
$arrayfecha[3]=$_POST['fechadia4'];
$arrayfecha[4]=$_POST['fechadia5'];
$arrayfecha[5]=$_POST['fechadia6'];
$arrayfecha[6]=$_POST['fechadia7'];

$hd[0]=$_POST['hd0'];
$hd[1]=$_POST['hd1'];
$hd[2]=$_POST['hd2'];
$hd[3]=$_POST['hd3'];
$hd[4]=$_POST['hd4'];
$hd[5]=$_POST['hd5'];
$hd[6]=$_POST['hd6'];

$feriado[0]=$_POST['feriado0'];
$feriado[1]=$_POST['feriado1'];
$feriado[2]=$_POST['feriado2'];
$feriado[3]=$_POST['feriado3'];
$feriado[4]=$_POST['feriado4'];
$feriado[5]=$_POST['feriado5'];
$feriado[6]=$_POST['feriado6'];

$hed[0]=$_POST['hed0'];
$hed[1]=$_POST['hed1'];
$hed[2]=$_POST['hed2'];
$hed[3]=$_POST['hed3'];
$hed[4]=$_POST['hed4'];
$hed[5]=$_POST['hed5'];
$hed[6]=$_POST['hed6'];

$hedp[0]=$_POST['hedp0'];
$hedp[1]=$_POST['hedp1'];
$hedp[2]=$_POST['hedp2'];
$hedp[3]=$_POST['hedp3'];
$hedp[4]=$_POST['hedp4'];
$hedp[5]=$_POST['hedp5'];
$hedp[6]=$_POST['hedp6'];

$trcd[0]=$_POST['trcd0'];
$trcd[1]=$_POST['trcd1'];
$trcd[2]=$_POST['trcd2'];
$trcd[3]=$_POST['trcd3'];
$trcd[4]=$_POST['trcd4'];
$trcd[5]=$_POST['trcd5'];
$trcd[6]=$_POST['trcd6'];

$bonocturno[0]=$_POST['bonocturno0'];
$bonocturno[1]=$_POST['bonocturno1'];
$bonocturno[2]=$_POST['bonocturno2'];
$bonocturno[3]=$_POST['bonocturno3'];
$bonocturno[4]=$_POST['bonocturno4'];
$bonocturno[5]=$_POST['bonocturno5'];
$bonocturno[6]=$_POST['bonocturno6'];

$hen[0]=$_POST['hen0'];
$hen[1]=$_POST['hen1'];
$hen[2]=$_POST['hen2'];
$hen[3]=$_POST['hen3'];
$hen[4]=$_POST['hen4'];
$hen[5]=$_POST['hen5'];
$hen[6]=$_POST['hen6'];

$henp[0]=$_POST['henp0'];
$henp[1]=$_POST['henp1'];
$henp[2]=$_POST['henp2'];
$henp[3]=$_POST['henp3'];
$henp[4]=$_POST['henp4'];
$henp[5]=$_POST['henp5'];
$henp[6]=$_POST['henp6'];

$trcn[0]=$_POST['trcn0'];
$trcn[1]=$_POST['trcn1'];
$trcn[2]=$_POST['trcn2'];
$trcn[3]=$_POST['trcn3'];
$trcn[4]=$_POST['trcn4'];
$trcn[5]=$_POST['trcn5'];
$trcn[6]=$_POST['trcn6'];

$km[0]=$_POST['km0'];
$km[1]=$_POST['km1'];
$km[2]=$_POST['km2'];
$km[3]=$_POST['km3'];
$km[4]=$_POST['km4'];
$km[5]=$_POST['km5'];
$km[6]=$_POST['km6'];

$movilizacion[0]=$_POST['movilizacion0'];
$movilizacion[1]=$_POST['movilizacion1'];
$movilizacion[2]=$_POST['movilizacion2'];
$movilizacion[3]=$_POST['movilizacion3'];
$movilizacion[4]=$_POST['movilizacion4'];
$movilizacion[5]=$_POST['movilizacion5'];
$movilizacion[6]=$_POST['movilizacion6'];

$ctc[0]=$_POST['ctc0'];
$ctc[1]=$_POST['ctc1'];
$ctc[2]=$_POST['ctc2'];
$ctc[3]=$_POST['ctc3'];
$ctc[4]=$_POST['ctc4'];
$ctc[5]=$_POST['ctc5'];
$ctc[6]=$_POST['ctc6'];

$ctl[0]=$_POST['ctl0'];
$ctl[1]=$_POST['ctl1'];
$ctl[2]=$_POST['ctl2'];
$ctl[3]=$_POST['ctl3'];
$ctl[4]=$_POST['ctl4'];
$ctl[5]=$_POST['ctl5'];
$ctl[6]=$_POST['ctl6'];

$ctc7mo[0]=$_POST['ctc7mo0'];
$ctc7mo[1]=$_POST['ctc7mo1'];
$ctc7mo[2]=$_POST['ctc7mo2'];
$ctc7mo[3]=$_POST['ctc7mo3'];
$ctc7mo[4]=$_POST['ctc7mo4'];
$ctc7mo[5]=$_POST['ctc7mo5'];
$ctc7mo[6]=$_POST['ctc7mo6'];

$ctl7mo[0]=$_POST['ctl7mo0'];
$ctl7mo[1]=$_POST['ctl7mo1'];
$ctl7mo[2]=$_POST['ctl7mo2'];
$ctl7mo[3]=$_POST['ctl7mo3'];
$ctl7mo[4]=$_POST['ctl7mo4'];
$ctl7mo[5]=$_POST['ctl7mo5'];
$ctl7mo[6]=$_POST['ctl7mo6'];

$clave221[0]=$_POST['clave2210'];
$clave221[1]=$_POST['clave2211'];
$clave221[2]=$_POST['clave2212'];
$clave221[3]=$_POST['clave2213'];
$clave221[4]=$_POST['clave2214'];
$clave221[5]=$_POST['clave2215'];
$clave221[6]=$_POST['clave2216'];

$clave277[0]=$_POST['clave2770'];
$clave277[1]=$_POST['clave2771'];
$clave277[2]=$_POST['clave2772'];
$clave277[3]=$_POST['clave2773'];
$clave277[4]=$_POST['clave2774'];
$clave277[5]=$_POST['clave2775'];
$clave277[6]=$_POST['clave2776'];

$reposo[0]=$_POST['reposo0'];
$reposo[1]=$_POST['reposo1'];
$reposo[2]=$_POST['reposo2'];
$reposo[3]=$_POST['reposo3'];
$reposo[4]=$_POST['reposo4'];
$reposo[5]=$_POST['reposo5'];
$reposo[6]=$_POST['reposo6'];

$lugar[0]=substr ($_POST['lugar0'],0,15);
$lugar[1]=substr ($_POST['lugar1'],0,15);
$lugar[2]=substr ($_POST['lugar2'],0,15);
$lugar[3]=substr ($_POST['lugar3'],0,15);
$lugar[4]=substr ($_POST['lugar4'],0,15);
$lugar[5]=substr ($_POST['lugar5'],0,15);
$lugar[6]=substr ($_POST['lugar6'],0,15);

$observacion[0]=$_POST['observacion0'];
$observacion[1]=$_POST['observacion1'];
$observacion[2]=$_POST['observacion2'];
$observacion[3]=$_POST['observacion3'];
$observacion[4]=$_POST['observacion4'];
$observacion[5]=$_POST['observacion5'];
$observacion[6]=$_POST['observacion6'];

$tipod[0]=$_POST['tipod0'];
$tipod[1]=$_POST['tipod1'];
$tipod[2]=$_POST['tipod2'];
$tipod[3]=$_POST['tipod3'];
$tipod[4]=$_POST['tipod4'];
$tipod[5]=$_POST['tipod5'];
$tipod[6]=$_POST['tipod6'];

$manej[0]=$_POST['mn0'];
$manej[1]=$_POST['mn1'];
$manej[2]=$_POST['mn2'];
$manej[3]=$_POST['mn3'];
$manej[4]=$_POST['mn4'];
$manej[5]=$_POST['mn5'];
$manej[6]=$_POST['mn6'];

$vpropio[0]=$_POST['vehiculo_propio1'];
$vpropio[1]=$_POST['vehiculo_propio2'];
$vpropio[2]=$_POST['vehiculo_propio3'];
$vpropio[3]=$_POST['vehiculo_propio4'];
$vpropio[4]=$_POST['vehiculo_propio5'];
$vpropio[5]=$_POST['vehiculo_propio6'];
$vpropio[6]=$_POST['vehiculo_propio7'];

foreach ($_POST['ci'] as $ci){
$query1 = mysql_query("SELECT * FROM traba WHERE ci='$ci'");
while ($row=mysql_fetch_array($query1))
			{
			$regionm=$row['region'];
			$direccionm=$row['direccion'];
			$gerenciam=$row['gerencia'];
			$coordinacionm=$row['coordinacion'];
			$estructuram=$row['estructura'];
			$id_estructuram=$row['id_estructura'];
			$jefaturam=$row['jefatura'];
			$cim=$row['ci'];
			$estatusm=$row['estatus'];
			$man=$row['manejo'];
			}
	$cont=0;
	while ($cont<=6)
		{
		$newfecham=$arrayfecha[$cont];
		$tipodiam=$tipod[$cont];
		$querymain = mysql_query("SELECT * FROM jornada WHERE ci='$cim' AND fecha='$newfecham'");
		if(mysql_num_rows($querymain)==0)
			{
			$kmm=$km[$cont];
			switch($tipodiam)
			{
			case 1:
				if($kmm<25)
					{
						$vcim=0;
						$vsim=0;
						$kilometrajem=0;
					}
				if($kmm>=25 && $kmm<100)
					{
						$vcim=$corto_ci;
						$vsim=$corto_si;
						if($vpropio[$cont]=="on")
					{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
					}	
				}
				if($kmm>=100)
					{
						$vcim=$largo_ci;
						$vsim=$largo_si;
						if($vpropio[$cont]=="on")
					{
						$kilometrajem=$kmm*2*0.1;
					}else{
						$kilometrajem=0;
					}	
				}
			$hdm=$hd[$cont];
			$feriadom=$feriado[$cont];
			$hedm=$hed[$cont];
			$hedpm=$hedp[$cont];
			$trcdm=$trcd[$cont];
			$bonocturnom=$bonocturno[$cont];
			$henm=$hen[$cont];
			$henpm=$henp[$cont];
			$trcnm=$trcn[$cont];
			switch($man)
				{
				case "SI":
					$manejom=$manej[$cont]*$manejobd;
				break;
				case "NO":
					$manejom=0;
				break;
				}
			$movilizacionm=$movilizacion[$cont];
			
			$ctcm=$ctc[$cont];
			$ctlm=$ctl[$cont];
			if($feriado[$cont]!=0){
				$ctc7mom=$ctc7mo[$cont];
				$ctl7mom=$ctl7mo[$cont];
			}else{
				$ctc7mom=0;
				$ctl7mom=0;
			}
			
			$clave221m=$clave221[$cont];
			$clave277m=$clave277[$cont];
			$reposom=$reposo[$cont];
			$lugarm=$lugar[$cont];
			$observacionm=$observacion[$cont];
			break;
			
			case 2:
				if($kmm<25)
					{
						$vcim=0;
						$vsim=0;
						$kilometrajem=0;
					}
				if($kmm>=25 && $kmm<100)
					{
						$vcim=$corto_ci;
						$vsim=$corto_si;
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}	
					}
				if($kmm>=100)
					{
						$vcim=$largo_ci;
						$vsim=$largo_si;
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}	
					}
			$hdm=$hd[$cont];
			$feriadom=$feriado[$cont];
			$hedm=$hed[$cont];
			$hedpm=$hedp[$cont];
			$trcdm=$trcd[$cont];
			$bonocturnom=$bonocturno[$cont];
			$henm=$hen[$cont];
			$henpm=$henp[$cont];
			$trcnm=$trcn[$cont];
			switch($man)
				{
				case "SI":
					$manejom=$manej[$cont]*$manejobd;
				break;
				case "NO":
					$manejom=0;
				break;
				}
			
			$ctcm=$ctc[$cont];
			$ctlm=$ctl[$cont];
			if($feriado[$cont]!=0){
				$ctc7mom=$ctc7mo[$cont];
				$ctl7mom=$ctl7mo[$cont];
			}else{
				$ctc7mom=0;
				$ctl7mom=0;
			}
			
			$movilizacionm=$movilizacion[$cont];
			$clave221m=$clave221[$cont];
			$clave277m=$clave277[$cont];
			$reposom=$reposo[$cont];
			$lugarm=$lugar[$cont];
			$observacionm=$observacion[$cont];
			break;
					
			case 3:
				if($kmm<25)
					{
						$vcim=0;
						$vsim=0;
						$kilometrajem=0;
					}
				if($kmm>=25 && $kmm<100)
					{
						$vcim=$corto_ci;
						$vsim=$corto_si;
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}	
					}
				if($kmm>=100)
					{
						$vcim=$largo_ci;
						$vsim=$largo_si;
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}	
					}
			$hdm=$hd[$cont];
			$feriadom=$feriado[$cont];
			$hedm=$hed[$cont];
			$hedpm=$hedp[$cont];
			$trcdm=$trcd[$cont];
			$bonocturnom=$bonocturno[$cont];
			$henm=$hen[$cont];
			$henpm=$henp[$cont];
			$trcnm=$trcn[$cont];
			switch($man)
				{
				case "SI":
					$manejom=$manej[$cont]*$manejobd;
				break;
				case "NO":
					$manejom=0;
				break;
				}
			
			$ctcm=$ctc[$cont];
			$ctlm=$ctl[$cont];
			$ctc7mom=$ctc7mo[$cont];
			$ctl7mom=$ctl7mo[$cont];
			
			$movilizacionm=$movilizacion[$cont];
			$clave221m=$clave221[$cont];
			$clave277m=$clave277[$cont];
			$reposom=$reposo[$cont];
			$lugarm=$lugar[$cont];
			$observacionm=$observacion[$cont];
			break;
					
			case 4:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm=" LIBRE";
			break;
			
			case 5:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="AUSENTE";
			break;
			
			case 6:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			//--------------------------
			$day=substr($newfecham,8,2);
			$month=substr($newfecham,5,2);
			$year=substr($newfecham,0,4);
			
			$dia_semana=date ("l", mktime(0, 0, 0,$month, $day, $year));
			
			switch($dia_semana)
				{
				case "Saturday":
							$reposom=4;
				break;
				default:
							$reposom=8;
				break;
				}
			//----------------------------
			$lugarm="-";
			$observacionm="REPOSO";
			break;
			
			case 7:
			$hdm=8;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="COMPENSATORIO";
			break;
			
			case 8:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="VACACIONES";
			break;
			
			case 9:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="PERMISO NO REMUNERADO";
			break;
			
			case 10:
			if($kmm<25)
					{
						$vcim=0;
						$vsim=0;
						$kilometrajem=0;
					}
				if($kmm>=25 && $kmm<100)
					{
						$vcim=$corto_ci;
						$vsim=$corto_si;
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
				if($kmm>=100)
					{
						$vcim=$largo_ci;
						$vsim=$largo_si;	
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
			
			$hdm=8;
			$feriadom=$feriado[$cont];
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$manejom=0;
			$ctcm=$ctc[$cont];
			$ctlm=$ctl[$cont];
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm=$lugar[$cont];
			$observacionm="PERMISO REMUNERADO. ".$observacion[$cont];
			break;
			
			case 11:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="7M0 D&Iacute;A LIBRE";
			$tipodiam=11;
			break;
			
			case 12:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="PERMISO SINDICAL";
			break;
			
			case 13:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			//--------------------------
			$day=substr($newfecham,8,2);
			$month=substr($newfecham,5,2);
			$year=substr($newfecham,0,4);
			
			$dia_semana=date ("l", mktime(0, 0, 0,$month, $day, $year));
			
			switch($dia_semana)
				{
				case "Saturday":
							$reposom=4;
				break;
				default:
							$reposom=8;
				break;
				}
			//----------------------------
			$lugarm="-";
			$observacionm="7MO DE REPOSO. ".$observacion[$cont];
			break;

			}

$sql = "INSERT INTO jornada (region,direccion,gerencia,coordinacion,estructura,id_estructura,jefatura,ci,fecha,estatus,hd,feriado,hed,hedp,trcd,bonocturno,hen,henp,trcn,vci,vsi,km,kilometraje,manejo,movilizacion,clave221,clave277,reposo,lugar,observacion,tipodia,horariotarjeta,ctc,ctl,ctc7mo,ctl7mo) VALUES('$regionm','$direccionm','$gerenciam','$coordinacionm','$estructuram','$id_estructuram','$jefaturam','$ci','$newfecham','$estatusm','$hdm','$feriadom','$hedm','$hedpm','$trcdm','$bonocturnom','$henm','$henpm','$trcnm','$vcim','$vsim','$kmm','$kilometrajem','$manejom','$movilizacionm','$clave221m','$clave277m','$reposom','$lugarm','$observacionm','$tipodiam','$horariom','$ctcm','$ctlm','$ctc7mom','$ctl7mom')";
$result1 = mysql_query($sql);

		
		}else{
			$kmm=$km[$cont];
			switch($tipodiam)
			{
			case 1:
				if($kmm<25)
					{
						$vcim=0;
						$vsim=0;
						$kilometrajem=0;
					}
				if($kmm>=25 && $kmm<100)
					{
						$vcim=$corto_ci;
						$vsim=$corto_si;
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
				if($kmm>=100)
					{
						$vcim=$largo_ci;
						$vsim=$largo_si;	
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
			
			$hdm=$hd[$cont];
			$feriadom=$feriado[$cont];
			$hedm=$hed[$cont];
			$hedpm=$hedp[$cont];
			$trcdm=$trcd[$cont];
			$bonocturnom=$bonocturno[$cont];
			$henm=$hen[$cont];
			$henpm=$henp[$cont];
			$trcnm=$trcn[$cont];
			switch($man)
				{
				case "SI":
					$manejom=$manej[$cont]*$manejobd;
				break;
				case "NO":
					$manejom=0;
				break;
				}
			$ctcm=$ctc[$cont];
			$ctlm=$ctl[$cont];
			if($feriado[$cont]!=0){
				$ctc7mom=$ctc7mo[$cont];
				$ctl7mom=$ctl7mo[$cont];
			}else{
				$ctc7mom=0;
				$ctl7mom=0;
			}
			$movilizacionm=$movilizacion[$cont];
			$clave221m=$clave221[$cont];
			$clave277m=$clave277[$cont];
			$reposom=$reposo[$cont];
			$lugarm=$lugar[$cont];
			$observacionm=$observacion[$cont];
			break;
			
			case 2:
				if($kmm<25)
					{
						$vcim=0;
						$vsim=0;
						$kilometrajem=0;
					}
				if($kmm>=25 && $kmm<100)
					{
						$vcim=$corto_ci;
						$vsim=$corto_si;
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
				if($kmm>=100)
					{
						$vcim=$largo_ci;
						$vsim=$largo_si;	
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
			
			$hdm=$hd[$cont];
			$feriadom=$feriado[$cont];
			$hedm=$hed[$cont];
			$hedpm=$hedp[$cont];
			$trcdm=$trcd[$cont];
			$bonocturnom=$bonocturno[$cont];
			$henm=$hen[$cont];
			$henpm=$henp[$cont];
			$trcnm=$trcn[$cont];
			switch($man)
				{
				case "SI":
					$manejom=$manej[$cont]*$manejobd;
				break;
				case "NO":
					$manejom=0;
				break;
				}
			$ctcm=$ctc[$cont];
			$ctlm=$ctl[$cont];
			if($feriado[$cont]!=0){
				$ctc7mom=$ctc7mo[$cont];
				$ctl7mom=$ctl7mo[$cont];
			}else{
				$ctc7mom=0;
				$ctl7mom=0;
			}
			$movilizacionm=$movilizacion[$cont];
			$clave221m=$clave221[$cont];
			$clave277m=$clave277[$cont];
			$reposom=$reposo[$cont];
			$lugarm=$lugar[$cont];
			$observacionm=$observacion[$cont];
			break;
			
			case 3:
				if($kmm<25)
					{
						$vcim=0;
						$vsim=0;
						$kilometrajem=0;
					}
				if($kmm>=25 && $kmm<100)
					{
						$vcim=$corto_ci;
						$vsim=$corto_si;
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
				if($kmm>=100)
					{
						$vcim=$largo_ci;
						$vsim=$largo_si;	
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
			
			$hdm=$hd[$cont];
			$feriadom=$feriado[$cont];
			$hedm=$hed[$cont];
			$hedpm=$hedp[$cont];
			$trcdm=$trcd[$cont];
			$bonocturnom=$bonocturno[$cont];
			$henm=$hen[$cont];
			$henpm=$henp[$cont];
			$trcnm=$trcn[$cont];
			switch($man)
				{
				case "SI":
					$manejom=$manej[$cont]*$manejobd;
				break;
				case "NO":
					$manejom=0;
				break;
				}
			$ctcm=$ctc[$cont];
			$ctlm=$ctl[$cont];
			$ctc7mom=$ctc7mo[$cont];
			$ctl7mom=$ctl7mo[$cont];
			$movilizacionm=$movilizacion[$cont];
			$clave221m=$clave221[$cont];
			$clave277m=$clave277[$cont];
			$reposom=$reposo[$cont];
			$lugarm=$lugar[$cont];
			$observacionm=$observacion[$cont];
			break;
			
			case 4:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="LIBRE";
			break;
			
			case 5:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="AUSENTE";
			break;
			
			case 6:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			//--------------------------
			
			$day=substr($newfecham,8,2);
			$month=substr($newfecham,5,2);
			$year=substr($newfecham,0,4);
			
			$dia_semana=date ("l", mktime(0, 0, 0,$month, $day, $year));
			$dia_semana;
			switch($dia_semana)
				{
				case "Saturday":
							$reposom=4;
				break;
				default:
							$reposom=8;
				break;
			}
			//----------------------------
			$lugarm="-";
			$observacionm="REPOSO";
			break;
			
			case 7:
			$hdm=8;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="COMPENSATORIO";
			break;
			
			case 8:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="VACACIONES";
			break;
			
			case 9:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="PERMISO NO REMUNERADO";
			break;
			
			case 10:
			if($kmm<25)
					{
						$vcim=0;
						$vsim=0;
						$kilometrajem=0;
					}
				if($kmm>=25 && $kmm<100)
					{
						$vcim=$corto_ci;
						$vsim=$corto_si;
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
				if($kmm>=100)
					{
						$vcim=$largo_ci;
						$vsim=$largo_si;	
						if($vpropio[$cont]=="on")
						{
						$kilometrajem=$kmm*2*0.1;
						}else{
						$kilometrajem=0;
						}
					}
			
			$hdm=8;
			$feriadom=$feriado[$cont];
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm=$lugar[$cont];
			$observacionm="PERMISO REMUNERADO. ".$observacion[$cont];
			break;
			
			case 11:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="7M0 D&Iacute;A LIBRE";
			break;
			
			case 12:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			$reposom=0;
			$lugarm="-";
			$observacionm="PERMISO SINDICAL";
			break;
			
			case 13:
			$hdm=0;
			$feriadom=0;
			$hedm=0;
			$hedpm=0;
			$trcdm=0;
			$bonocturnom=0;
			$henm=0;
			$henpm=0;
			$trcnm=0;
			$vcim=0;
			$vsim=0;
			$kmm=0;
			$kilometrajem=0;
			$manejom=0;
			$ctcm=0;
			$ctlm=0;
			$ctc7mom=0;
			$ctl7mom=0;
			$movilizacionm=0;
			$clave221m=0;
			$clave277m=0;
			//--------------------------
			$day=substr($newfecham,8,2);
			$month=substr($newfecham,5,2);
			$year=substr($newfecham,0,4);
			
			$dia_semana=date ("l", mktime(0, 0, 0,$month, $day, $year));
			
			switch($dia_semana)
				{
				case "Saturday":
							$reposom=4;
				break;
				default:
							$reposom=8;
				break;
				}
			//----------------------------
			$lugarm="-";
			$observacionm="7MO DE REPOSO. ".$observacion[$cont];
			break;
			
			}
			
$sSQL="Update jornada Set region='$regionm',direccion='$direccionm',gerencia='$gerenciam',coordinacion='$coordinacionm',estructura='$estructuram',id_estructura='$id_estructuram',jefatura='$jefaturam' ,ci='$cim',fecha='$newfecham',estatus='$estatusm',hd='$hdm',feriado='$feriadom',hed='$hedm',hedp='$hedpm',trcd='$trcdm',bonocturno='$bonocturnom',hen='$henm',henp='$henpm',trcn='$trcnm',vci='$vcim',vsi='$vsim',km='$kmm',kilometraje='$kilometrajem',manejo='$manejom',movilizacion='$movilizacionm',clave221='$clave221m',clave277='$clave277m',reposo='$reposom',lugar='$lugarm',observacion='$observacionm',tipodia='$tipodiam',horariotarjeta='$horariom',ctc='$ctcm',ctl='$ctlm',ctc7mo='$ctc7mom',ctl7mo='$ctl7mo' where ci='$cim' and fecha='$newfecham'";
$result2 = mysql_query($sSQL);

		}
		$cont=$cont+1;
		}
}

	echo "<H2><font color='blue'>Los datos fueron guardados con &eacute;xito!!!</font></H2>";
	echo '<div align="center">';
	echo '<table width="200" border="0">';
	echo '<tr>';
	
mysql_free_result($query1) and mysql_free_result($querymain);
}

mysql_close($dbh);
?>
                            </p>
                            <p>&nbsp;</p>
                            <div align="center"> <span class="t12g Estilo30"><span class="Estilo34">&iquest;Desea incluir otra jornada?
                              </p>
                                </span></span>
          <table width="243" border="0">
                                  <tr>
                                    <td width="113"><div align="center"><font color="#FF0000" size="2"><a title="Ayuda sobre el manejo del SARTS" href="#">
                                      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="103" height="24">
                                        <param name="movie" value="button34.swf">
                                        <param name="quality" value="high">
                                        <embed src="button34.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="103" height="24" ></embed>
                                      </object>
                                    </a></font></div></td>
                                    <td width="114"><div align="center">
                                      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="103" height="24">
                                        <param name="BGCOLOR" value="">
                                        <param name="movie" value="button19.swf">
                                        <param name="quality" value="high">
                                        <embed src="button19.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="103" height="24" ></embed>
                                      </object>
                                    </div></td>
                                  </tr>
                              </table>
          <p>&nbsp;</p><form action="inc_semana_grupo.php" method="post">
          <p class="t12g Estilo49">&iquest;Retornar a la pantalla anterior?</p>
	  <p>
	  <input type="hidden" name="fecha_semana_grupo" value="<?php echo $_POST['fecha_semana_grupo'];?>">
	  <input type="hidden" name="grupo_inc_semana" value="<?php echo $_POST['grupo_inc_semana'];?>">
	  <input type="hidden" name="cuenta" value="<?php echo $_POST['cuenta'];?>">
	  <input type="hidden" name="plt_semana" value="<?php echo $_POST['plt_semana'];?>">
	  </p>
		   <p><input type="submit" name="aceptar" value="Continuar" style="background:#FFB400"></p>
          </form>
                            </div>
                            <h1 align="right">

                              <table width="47%" border="0" cellspacing="0" cellpadding="0">
                                <tr> </tr>
                              </table>
                          </h1></td>
					</tr>
				  </table>				</td>
				<td width="16">&nbsp;</td>
			  </tr>
			</table>		  </td>
		</tr>
	  </table>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <table width="5" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="5">&nbsp;</td>
        </tr>
      </table>
      </td>
	    <td width="297" valign="top" background="images/index_32.gif">
		   <div align="center" class="t14w Estilo37"></div>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
		      <td height="8"><span class="t12g Estilo44"><span class="Estilo47"><img src="images/index_57.gif" width=240 height=1 alt="">
		        </span></span>
		        <div align="center" class="t12g Estilo44">SISTEMA ARTS</div>
		        <ul class="Estilo9"><li class="Estilo11 Estilo48"><a title="inicio.htm" href="inicio.html" target="_self">Inicio</a></li>
            <li class="Estilo11 Estilo48"><a title="antecedentes.htm" href="antecedentes.htm" target="_self">Antecedentes</a></li>
            <li class="Estilo11 Estilo48"><a title="Objetivos.html" href="Objetivos.html" target="_self">Objetivos</a></li>
            <li class="Estilo11 Estilo48"><span class="Estilo10 Estilo48">Trabajadores
                </span>
              <ul>
                    <li><a title="cargar_traba.php" href="cargar_traba.php" target="_self">Inclusion</a></li>
                    <li><a title="consulta_trabaj.php" href="consulta_trabaj.php" target="_self">Consulta - Reporte</a></li>
                    <li><a title="actualizar_trabaj.php" href="actualizar_trabaj.php" target="_self">Modificacion</a></li>
                    <li><a title="elim_traba.php" href="elim_traba.php" target="_self">Eliminacion</a></li>
                    <li></li>
                    <li><a title="menu_graficar_trabaj.php" href="menu_graficar_trabaj.php" target="_self">Graficacion</a></li>
                </ul>
            </li>
            <li class="Estilo11 Estilo48"><span class="Estilo10">Jornadas
              </span>
              <ul>
                <li><a title="cargar_jornada.html" href="cargar_jornada.php" target="_self">Inclusion</a></li>
                <li><a title="consulta_jornada.php" href="consulta_jornada.php" target="_self">Consulta</a></li>
                <li><a title="actualizar_jornada.php" href="actualizar_jornada.php" target="_self">Modificaci&oacute;n</a></li>
                <li><a title="delete_jornada.php" href="elim_jornada.php" target="_self">Eliminacion</a></li>
                <li><span class="Estilo48"><a title="menu_graficar_jornada.php" href="menu_graficar_jornada.php" target="_self">Graficaci&oacute;n</a></span></li></ul>
                <li class="Estilo48">Plantillas</li>
                <ul class="Estilo48">
                  <li><a title="Crear Plantilla" href="crear_plantilla.php" target="_self">Inclusi&oacute;n</a></li>
                  <li><a title="Consultar Plantilla" href="consulta_plantilla.php" target="_self">Consultar</a></li>
                  <li><a title="Modificar Plantilla" href="actualizar_plantilla.php" target="_self">Modificacion</a></li>
                  <li><a title="Eliminar Plantilla" href="elim_plantilla.php" target="_self">Eliminacion</a></li>
                </ul>
                
              </li>
            <li class="Estilo11 Estilo48"><span class="Estilo10 Estilo48">Menu Admi</span><span class="Estilo10">n</span>
              <ul><li><strong>Trabajadores</strong>
                <ul><li><a title="consulta_trabaj.php" href="consulta_trabaj.php" target="_self">Consulta - Reporte</a></li>
                        <li><a title="actualizar_trabaj.php" href="actualizar_trabaj.php" target="_self">Modificacion</a></li>
                        <li><a title="elim_traba.php" href="elim_traba.php" target="_self">Eliminacion</a></li>
                        <li><a title="menu_graficar_trabaj.php" href="menu_graficar_trabaj.php" target="_self">Graficacion</a></li>
                      </ul>
                    </li>
                    <li><strong>Usuarios
                        </strong>
                      <ul>
                          <li><a title="cargar_user.php" href="cargar_user.php" target="_self">Inclusion</a></li>
                          <li><a title="consulta_user.php" href="consulta_user.php" target="_self">Consulta - Reporte</a></li>
                          <li><a title="actualizar_user.php" href="actualizar_user.php" target="_self">Modificacion</a></li>
                          <li><a title="elim_user.php" href="elim_user.php" target="_self">Eliminacion</a></li>
                          <li><a title="menu_graficar_user.php" href="menu_graficar_user.php" target="_self">Graficacion</a></li>
                      </ul>
                    </li>
                    <li><a title="consulta_jornada.php" href="consulta_jornada.php" target="_self">Consulta - Reporte</a></li>
                    <li><a title="actualizar_jornada.php" href="actualizar_jornada.php" target="_self">Modificacion</a></li>
                    <li><a title="elim_jornada.php" href="elim_jornada.php" target="_self">Eliminacion</a></li>
                  </ul>
            </li>
            <li class="Estilo11 Estilo48"><a title="download.html" href="download.html" target="_self">Descargas</a></li>
            <li class="Estilo11 Estilo48"><a href="menu_sarts.html">Sistema ARTS                        </a></li>
            <li class="Estilo11 Estilo48">Contacto SARTS</li>
            <li class="Estilo11 Estilo48"><span class="Estilo10">FAQ
                
              </span>
              <ul>
                    <li>Preguntas Generales</li>
                    <li>Manual de Usuario</li>
                </ul>
            </li>
            <li class="Estilo11 Estilo48">Ayuda Online (proximamente)</li>
            <li class="Estilo11 Estilo48">Forums (proximanete)</li>
        </ul>			  </td>
		</tr>
	  </table>
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
		  <td><img src="images/index_57.gif" width=240 height=1 alt=""></td>
		</tr>
	  </table>
      <div align="left">
        <div align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Desarrollado 
          para:</strong></font></strong></font></strong></font>        </div>
        <div align="center"><img src="images/logo de cadafe_2.gif" width="148" height="90"></div>
            <p align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#CCCCCC" size="4">Regi&oacute;n 
              4</font></strong></font></strong></font></strong></font></p>
            <p align="center">
          <script><!--
dows = new Array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado");
months = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
now = new Date();
dow = now.getDay();
d = now.getDate();
m = now.getMonth();
h = now.getTime();
y = now.getFullYear();
document.write(dows[dow]+" "+d+" de "+months[m]+" de "+y);
//--></script></p></div></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td background="images/index_66.gif" class="t12w"><b>&nbsp;&nbsp;&copy;2006-2007 
      MaxSystem.NET &nbsp;Derechos Reservados</b></td>
	<td width="102"><img src="images/index_69.jpg" width=102 height=36 alt=""></td>
	<td width="222" background="images/index_70.gif" align="center" class="t12w"><div align="center"><a href="#" class="t12w"><b>Data/Privacidad</b></a><b> 
        � <a href="#" class="t12w">Accesabilidad</a></b></div></td>
  </tr>
</table>
</div></td>

</BODY>
</HTML>