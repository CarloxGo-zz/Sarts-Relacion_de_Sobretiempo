<HTML>
<HEAD>
<TITLE>Bienvenidos. Sistema ARTS Online</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1251">
<link rel="stylesheet" href="main.css" type="text/css" http-equiv="Window-target" content="_top"/>

<script type="text/javascript" language="JavaScript1.2" src="stmenu.js"></script>

<script type="text/javascript" id="sothink_dhtmlmenu"> 
<!--
 st_siteroot="Inclusion";
 st_jspath="stmenu.js";
 if(!window.location.href.indexOf("file:") && st_jspath.charAt(0)=="/")
  document.write('<script type="text/javascript" src="'+st_siteroot+st_jspath+'"><\/script>');
 else 
  document.write('<script type="text/javascript" src="'+st_jspath+'"><\/script>');
//--> </script>

<script language="JavaScript1.2">
<!--
var url="http://www.sarts.net.ve" 
var titulo="Sarts Online"
function agregar(){
if (document.all)
window.external.AddFavorite(url,titulo)
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' debe contener una direccion e-mail valida.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' debe contener un n&uacute;mero.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' debe contener un n&uacute;mero entre '+min+' y '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' es requerido.\n'; }
  } if (errors) alert('El(Los) siguente(s) Error(es) ha(n) ocurrido:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script> 

<style type="text/css">
<!--
.Estilo2 {font-size: 18px; color: #FFFFFF;}
a:link {
	color: #333333;
}
a:visited {
	color: #666666;
}
body {
	background-image: url();
}
a:hover {
	color: #FFFFFF;
}
a:active {
	color: #FFFFFF;
}
.Estilo9 {color: #FFFF00}
.Estilo10 {
	font-size: 16px;
	font-weight: bold;
}
a {
	font-weight: bold;
}
.Estilo11 {color: #FFFFFF}
.Estilo13 {
	color: #FFFFFF;
	font-size: 14px;
	font-weight: bold;
}
-->
</style>

<script language="JavaScript" type="text/JavaScript">
function enviar(){
var enviarme=confirm("Desea enviar el formulario?");
if (enviarme)
   return true ;
else
   return false ;
}
</script>
</HEAD>
<form name="autentificar" method="post" action="control.php">
<BODY BGCOLOR=#FFFFFF LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 tracingsrc="images/-downdis.gif" tracingopacity="100" oncontextmenu="return false">
<td colspan="3" valign="middle" bgcolor="#FF8D00"><div align="center"> 
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
<td align="right" background="images/index_01.gif"><img src="images/index_03.gif" width=59 height=34 alt=""><a href="inicio.php"><img src="images/index_ini.gif" alt="" width=82 height=34 border="0"></a><img src="images/index_faq.GIF" width=82 height=34 alt=""><img src="images/index_link.gif" width=89 height=34 alt=""><a href="finalizar_sesion.php" target="_self"><img src="images/index_sarts.gif" alt="" width=71 height=34 border="0"></a><img src="images/index_contac.GIF" width=85 height=34 alt=""></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td> <div align="right"> 
        <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="778" height="174">
          <param name="movie" value="3.swf">
          <param name="quality" value="high">
          <embed src="3.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="778" height="174"></embed></object>
        <font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"></font></div></td>
  </tr>
</table>
  <table width="777" border="0" bgcolor="#FF9900">
    <tr>
      <td width="37">&nbsp;</td>
      <td width="730"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="730" height="102">
        <param name="movie" value="imagenes especiales/2.swf">
        <param name="quality" value="high">
        <embed src="imagenes especiales/2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="730" height="102" ></embed>
      </object></td>
    </tr>
  </table>
  <div align="center">
  <table width="778" border="0">
    <tr><td><td width="767"><div align="right">
        Click aqui para accesar como usuario =&gt;
        <input name="Enviar" type="submit" style="background:#FFB400" lang="es" id="Enviar" onClick="MM_validateForm('login','','R','password','','R');return document.MM_returnValue" value="Enviar">
      </div></td>
    </tr>
  </table>
  </div>

<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td width="450" background="images/index_23.gif"><img src="images/index_22.gif" width=174 height=35 alt=""></td>
	<td background="images/index_27.gif"><img src="images/index_25.jpg" width=96 height=35 alt=""><img src="images/index_soft.GIF" width=92 height=35 alt=""></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0" bgcolor="#FAFAFA">
  <tr>
	<td width="481" align="right"> 
	  <table width="535" border="0" cellspacing="0" cellpadding="0">
		<tr>
		  <td width="274" valign="top">
			<table width="274" border="0" cellspacing="0" cellpadding="0" height="41">
			  <tr> 
				<td colspan="2"><img src="images/index_34.gif" width=274 height=2 alt=""></td>
			  </tr>
			  <tr> 
				<td width="5">&nbsp;</td>
				<td width="279" align="center"><img src="images/index_41.gif" width=10 height=11 alt=""><span class="t12g"> 
                  SARTS ONLINE</span></td>
			  </tr>
			</table>
		  </td>
		  <td width="261" align="right"><img src="images/index_30.gif" width=256 height=41 alt=""></td>
		</tr>
	  </table>
	  <table width="535" border="0" cellspacing="0" cellpadding="0">
		<tr> 
		  <td width="5">&nbsp;</td>
		  <td align="center" width="134"><img src="images/palmv_stand_scheduling_md_wht.gif" width="115" height="130"> 
          </td>
		  <td width="396" valign="top" class="bg_product"> 
			<table width="396" border="0" cellspacing="0" cellpadding="0">
			  <tr> 
				<td class="t12b" width="375"><p align="left"><font color="#FF8000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><em><font color="#009900" size="2"><strong>El 
                    SARTS Online permite de manera automatizada, eficiente y sencilla, 
                    relacionar las Jornadas de Sobretiempo generadas para el Personal 
                    Liniero de la Compa&ntilde;&igrave;a An&oacute;nima de Administraci&oacute;n y Fomento Electrico  (CADAFE) Venezuela</strong></font></em></font></p>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr> 
					  <td align="right"><h1 align="right">
                              <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="103" height="24">
                                <param name="BGCOLOR" value="">
                                <param name="BASE" value=".">
                                <param name="movie" value="button6.swf">
                                <param name="quality" value="high">
                                <embed src="button6.swf" width="103" height="24" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" base="." ></embed> 
                              </object>
                        </h1>
                        </td>
					</tr>
				  </table>
				</td>
				<td width="18">&nbsp;</td>
			  </tr>
			</table>
		  </td>
		</tr>
	  </table>
	  <table width="530" border="0" cellspacing="0" cellpadding="0">
		<tr>
		  <td width="530"><hr /></td>
		</tr>
	  </table>

	  <table width="535" border="0" cellspacing="0" cellpadding="0">
		<tr> 
		  <td width="274" valign="top"> 
			<table width="274" border="0" cellspacing="0" cellpadding="0" height="41">
			  <tr> 
				<td colspan="2"><img src="images/index_34.gif" width=274 height=2 alt=""></td>
			  </tr>
			  <tr> 
				<td width="5">&nbsp;</td>
				<td width="279" align="center"><img src="images/index_41.gif" width=10 height=11 alt=""><span class="t12g"> 
                  Informaci&oacute;n</span></td>
			  </tr>
			</table>
		  </td>
		  <td width="261" align="right"><img src="images/index_30.gif" width=256 height=41 alt=""></td>
		</tr>
	  </table>
	  <table width="535" border="0" cellspacing="0" cellpadding="0">
		<tr> 
		  <td width="5">&nbsp;</td>
		  <td align="center" width="134"> <p align="center">&nbsp;</p>
            <p>&nbsp;</p>
            <p><img src="images/Collageautomotor_2.jpg" width="131" height="117"></p>
            <p>&nbsp;</p></td>
		  <td width="396" valign="top" class="bg_product"> 
			<table width="396" border="0" cellspacing="0" cellpadding="0">
			  <tr>
				<td class="t12b" width="375"><p align="left"><font color="#FF8000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><em><font color="#3366CC">&quot;Concebido 
                    como un proyecto aislado en su fase inicial, en la actualidad 
                    se presenta como una herramienta adaptada a los nuevos tiempos, 
                    donde la Internet juega un papel importante, y la informacion 
                    que se obtiene de este software puede ser utilizada por programas 
                    informaticos generados en otros lenguajes y plataformas de 
                    desarrollo."</font></em></font></p>
				  <div align="right"><strong>Ing. Carlos H. Gonzalez N.</strong></div>
                      <ul>
                        <hr />
                        <p align="center"><img src="images/sarts-3D.gif" width="234" height="51">&nbsp;</p>
                        <table width="89%" height="82" border="0">
                          <tr> 
                            <td width="50%" height="78"><div align="center"><a href="menu_sarts.html"></a><img src="imagenes especiales/flecha.jpg" width="115" height="115"></div></td>
                            <td width="50%"><ul>
                                <li> 
                                  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="103" height="24">
                                    <param name="BGCOLOR" value="">
                                    <param name="BASE" value=".">
                                    <param name="movie" value="button7.swf">
                                    <param name="quality" value="high">
                                    <embed src="button7.swf" width="103" height="24" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" base="." ></embed> 
                                  </object>
                                </li>
                                <li> 
                                  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="103" height="24">
                                    <param name="BASE" value=".">
                                    <param name="BGCOLOR" value="">
                                    <param name="movie" value="button8.swf">
                                    <param name="quality" value="high">
                                    <embed src="button8.swf" width="103" height="24" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" base="." ></embed> 
                                  </object>
                                  <font color="#FF6600"><strong> </strong></font></li>
                                <li> <font color="#FF6600"><strong><font size="2"> 
                                  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="103" height="24">
                                    <param name="BGCOLOR" value="">
                                    <param name="movie" value="button9.swf">
                                    <param name="quality" value="high">
                                    <embed src="button9.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="103" height="24" ></embed> 
                                  </object>
                                  </font> </strong></font></li>
                                <li><font color="#FF6600"><strong><font size="2"> 
                                  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,0,0" width="103" height="24">
                                    <param name="movie" value="button10.swf">
                                    <param name="quality" value="high">
                                    <embed src="button10.swf" quality="high" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="103" height="24" ></embed> 
                                  </object>
                                  </font></strong></font></li>
                              </ul></td>
                          </tr>
                        </table>
                        <hr />
                      </ul>
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr> 
					  <td align="right" bgcolor="#0075E3"><div align="center">
					    <p><span class="Estilo13">Esp: Mapa de visitantes y sus ubicaciones en el mundo </span><a href="http://basicstat.com/maps/map1195591768.php" class="t12g Estilo11"> <img src="http://basicstat.com/maps/180/1195591768.jpg" border="1" alt="Site visitors world map" /></a></p>
					    </div></td>
					</tr>
				  </table>				</td>
				<td width="18">&nbsp;</td>
			  </tr>
			</table>
		  </td>
		</tr>
	  </table>
	  <table width="530" border="0" cellspacing="0" cellpadding="0">
		<tr> 
		  <td width="530"><img src="images/index_53.gif" width=535 height=12 alt=""></td>
		</tr>
	  </table>
	  <p>
	    <script>
if (document.all)
document.write('<a href="javascript:agregar()">Agregar SARTS a Favoritos</a>')
      </script>
	  </p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	  </td>
	    <td width="297" valign="top" background="images/index_32.gif">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
		      <td height="8"><img src="images/index_57.gif" width=240 height=1 alt=""><div align="center" class="t12g"><span class="Estilo2">Sistema ARTS</span></div>
<?
include ("includes/bdkey.php");
?>
        </ul>			  </td>
		</tr>
	  </table>
	  
	      <div align="left">
        <p align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Desarrollado 
          para:</strong></font></strong></font></strong></font></p>
        <div align="center"><a href="http://www.cadafe.gov.ve"><img src="images/logo%20de%20cadafe_2.gif" alt="" width="148" height="90" border="0"></a></div>
            <p align="center"><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#CCCCCC" size="4">Regi&oacute;n 
              4</font></strong></font></strong></font></strong></font></p>
            <div align="center">
          <script><!--
dows = new Array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado");
months = new Array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
now = new Date();
dow = now.getDay();
d = now.getDate();
m = now.getMonth();
h = now.getTime();
y = now.getFullYear();
document.write(dows[dow]+" "+d+" de "+months[m]+" de "+y);
//--></script>
</div>
      </div></td>
  </tr>
</table>
<table width="778" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td background="images/index_66.gif" class="t12w"><b>&nbsp;&nbsp;&copy;2006-2007 
      MaxSystem.NET &nbsp;Derechos Reservados</b></td>
	<td width="102"><img src="images/index_69.jpg" width=102 height=36 alt=""></td>
	<td width="222" background="images/index_70.gif" align="center" class="t12w"><div align="center"><a href="#" class="t12w"><b>Data/Privacidad</b></a><b> 
        � <a href="#" class="t12w">Accesabilidad</a></b></div></td>
  </tr>
</table>
      </div></td>
	  </form>

</BODY>
</HTML>