﻿<?php
/*
 * Si utilizas este codigo por favor no elimines esta cabecera.
 * Copyright 2007 Jorge J. Sariego <www.Tutores.org>
 * para mas Codigos, Scripts y Aplicaciones visita www.tutores.org
 */
include_once"conexiones.php";  //incluimos el archivo de conexiones a la base de datos
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Listado de Distritos y Jefaturas de Líneas dinamicas desde MySQL</title>
<!-- SCRIPT getHTTPObject -->
<!-- CODIGO OFRECIDO POR TUTORES.ORG -->
<script src="provincias.js" type="text/javascript"></script>
</head>
<body>