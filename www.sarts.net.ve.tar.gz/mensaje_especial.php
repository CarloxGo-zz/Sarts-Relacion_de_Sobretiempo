<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Documento sin t&iacute;tulo</title>
<style type="text/css">
<!--
.Estilo2 {
	font-size: 18px;
	font-weight: bold;
	color: #FF0000;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.Estilo3 {
	color: #0000FF;
	font-weight: bold;
}
.Estilo5 {color: #009900; }
-->
</style>
</head>
<BODY BGCOLOR=#FFFFFF background="images/bgb.gif" vlink="#0000FF" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 tracingsrc="images/-downdis.gif" tracingopacity="100" oncontextmenu="return false">
<div align="center">
  <p class="Estilo2"><u>Atenci�n</u></p>
  <p class="Estilo3">Ayuda  manejo del Sistema ARTS</p>
  <table width="314" border="1">
    <tr>
      <td width="113" class="Estilo3"><div align="center" class="Estilo5">Acci&oacute;n</div></td>
      <td width="125" class="Estilo3"><div align="center" class="Estilo5">Teclas</div></td>
    </tr>
    <tr>
      <td><div align="center">Ir a p&aacute;gina anterior </div></td>
      <td><div align="center">[ALT]+[Flecha Izquierda]</div></td>
    </tr>
    <tr>
      <td><div align="center">Ir a p&aacute;gina siguiente </div></td>
      <td><div align="center">[ALT]+[Flecha Derecha]</div></td>
    </tr>
    <tr>
      <td><div align="center">Bajar p&aacute;gina </div></td>
      <td><div align="center">[ALT]+[Flecha Izquierda]</div></td>
    </tr>
    <tr>
      <td><div align="center">Subir p&aacute;gina</div></td>
      <td><div align="center">[Flecha Subir] &oacute; [Pag Up] </div></td>
    </tr>
    <tr>
      <td><div align="center">Cerrar Sistema </div></td>
      <td><div align="center">[Flecha Bajar] &oacute; [Pag Dw] </div></td>
    </tr>
  </table>
  <p class="Estilo3">Nota: En teclado en Espa&ntilde;ol:</p>
  <table width="185" border="0">
    <tr>
      <td width="99"><span class="Estilo3">[Pag Up] = </span></td>
      <td width="76">[Re P&aacute;g] </td>
    </tr>
    <tr>
      <td><span class="Estilo3">[Pag Down] = </span></td>
      <td>[Av P&aacute;g] </td>
    </tr>
  </table>
  <p class="Estilo3">&nbsp;</p>
  <p class="Estilo3">&nbsp;</p>
</div>
</body>

</html>


