<?php
//$dbh = mysql_connect("mysql2.tupaginaweb.com.ve", "nstar23_user", "abc123") or die ("No se pudo conectar a la base de datos, motivo: ".mysql_error());
//mysql_select_db("nstar23_sarts",$dbh);

$dbh = mysql_connect("localhost", "root", "");
mysql_select_db("wwwsart_sarts",$dbh) or die("No se pudo conectar a la base de datos ".mysql_error());
?>