<HTML>
<HEAD>
<TITLE>Men� Lateral. Sistema ARTS Online</TITLE>
</HEAD>
<BODY BGCOLOR=#FFFFFF background="images/bgb.gif" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 onLoad="MM_preloadImages('images/18-1.gif','images/8-1.gif')" tracingsrc="images/-downdis.gif" tracingopacity="100" oncontextmenu="return false">
<?php
//Men� lateral
echo '<ul class="Estilo9"><li class="Estilo11 Estilo48"><a title="inicio.htm" href="inicio.html" target="_self">Inicio</a></li>
	<li class="Estilo11 Estilo48"><a title="antecedentes.htm" href="antecedentes.htm" target="_self">Antecedentes</a></li>
	<li class="Estilo11 Estilo48"><a title="Objetivos.html" href="Objetivos.html" target="_self">Objetivos</a></li>
	<li class="Estilo11 Estilo48"><span class="Estilo10 Estilo48">Trabajadores</span>
		<ul>
		<li><a title="Cargar Traba" href="cargar_traba.php" target="_self">Inclusi&oacute;n</a></li>
		<li><a title="Consultar Trabajador" href="consulta_trabaj.php" target="_self">Consulta - Reporte</a></li>
		<li><a title="Actualizar Trabajador" href="actualizar_trabaj.php" target="_self">Modificaci&oacute;n</a></li>
		<li><a title="Eliminar Trabajador nivel Usuario" href="elim_traba.php" target="_self">Eliminaci&oacute;n</a></li>
		<li><a title="Men� Gr�fica datos trabajador " href="menu_graficar_trabaj.php" target="_self">Graficaci&oacute;n</a></li>
    	</ul>
    </li>
    <li class="Estilo11 Estilo48"><span class="Estilo10">Jornadas</span>
		<ul>
		<li><a title="Cargar Jornadas" href="cargar_jornada.php" target="_self">Inclusi&oacute;n</a></li>
		<li><a title="Consultar Jornadas" href="consulta_jornada.php" target="_self">Consulta</a></li>
		<li><a title="Modiciar Jornadas" href="actualizar_jornada.php" target="_self">Modificaci&oacute;n</a></li>
		<li><a title="Eliminar Jornadas" href="elim_jornada.php" target="_self">Eliminaci&oacute;n</a></li>
		<li><span class="Estilo48"><a title="menu_graficar_jornada.php" href="menu_graficar_jornada.php" target="_self">Graficaci&oacute;n</a></span></li>
		</ul>
	<li class="Estilo11 Estilo48">Plantillas</li>
		<ul>
		<li><a title="Crear Plantilla" href="crear_plantilla.php" target="_self">Inclusi&oacute;n</a></li>
		<li><a title="Consultar Plantilla" href="consulta_plantilla.php" target="_self">Consultar</a></li>
		<li><a title="Modificar Plantilla" href="actualizar_plantilla.php" target="_self">Modificaci&oacute;n</a></li>
		<li><a title="Eliminar Plantilla" href="elim_plantilla.php" target="_self">Eliminaci&oacute;n</a></li>
		</ul>
	</li>
	<li class="Estilo48"><span class="Estilo10 Estilo48">Menu Admi</span><span class="Estilo10">n</span>
		<ul>
		<li><strong>Trabajadores</strong>
			<ul>
			<li><a title="consulta_trabaj.php" href="consulta_trabaj.php" target="_self">Consulta - Reporte</a></li>
			<li><a title="actualizar_trabaj.php" href="actualizar_trabaj.php" target="_self">Modificaci&oacute;n</a></li>
        	<li><a title="elim_traba.php" href="elim_traba.php" target="_self">Eliminacion</a></li>
        	<li><a title="menu_graficar_trabaj.php" href="menu_graficar_trabaj.php" target="_self">Graficaci&oacute;n</a></li>
        </ul></li>
	<li><strong>Usuarios</strong>
        <ul>
        <li><a title="Crear Usuario" href="cargar_user.php" target="_self">Inclusi&oacute;n</a></li>
		<li><a title="Pr�ximanmente" href="consulta_user.php" target="_self">Consulta - Reporte</a></li>
		<li><a title="Pr�ximanmente" href="actualizar_user.php" target="_self">Modificaci&oacute;n</a></li>
		<li><a title="Pr�ximanmente" href="elim_user.php" target="_self">Eliminaci&oacute;n</a></li>
		<li><a title="Pr�ximanmente" href="menu_graficar_user.php" target="_self">Graficaci&oacute;n</a></li>
		</ul></li>
	<li><strong>Adicionales</strong>
		<li class="Estilo11 Estilo48"><a title="Descargas" href="download.php" target="_self">Descargas</a></li>
		<li class="Estilo11 Estilo48"><a title="Men� SARTS" href="menu_sarts.html">Sistema ARTS</a></li>
		<li class="Estilo11 Estilo48"><a title="Contactar al Administrador" href="#">Contacto SARTS</a></li>
		<li class="Estilo11 Estilo48"><a title="FAQ" href="#">Preguntas del Sistema</a><ul>
		<li class="Estilo11 Estilo48"><a title="Manual de Usuario" href="#">Manual de Usuario</a></li>
		</ul></li>
	<li class="Estilo11 Estilo48">Ayuda Online (proximamente)</li>
		<li class="Estilo11 Estilo48">Chat SARTS(pr&oacute;ximanete)</li>
        </ul>';
?>
</BODY>
</HTML>