<html>
 <head>
  <script language="JavaScript">
   function abrirVentana() {
    open("popUp.htm","miVentana", "toolbar=no,directories=no,menubar=no,status=no");
   }
  </script>
 </head>
 <body>
  <form name="frm">
   <input type="button" name="boton" value="PopUp" onClick="abrirVentana()">
  </form>
 </body>
</html>  